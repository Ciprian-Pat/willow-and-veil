<?php
/**
 * One-time content setup: media library images, pages, menu and front page.
 *
 * Runs from the Playground blueprint, or from Appearance > Willow & Veil Setup on a live site.
 * Safe to run more than once: existing images and pages are reused, and page content is refreshed.
 *
 * @package willow-and-veil
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pages in menu order. content: file in inc/content/.
 */
function wv_page_definitions() {
	return array(
		array(
			'slug'        => 'home',
			'title'       => 'Home',
			'seo_title'   => 'Luxury Bridal Hair & Makeup in Austin, TX | Willow & Veil',
			'description' => 'Willow & Veil offers luxury bridal hair and makeup in Austin, Texas. Timeless, elevated artistry for brides, bridal parties and family, designed to photograph beautifully.',
			'menu'        => false,
		),
		array(
			'slug'        => 'about',
			'title'       => 'About',
			'seo_title'   => 'About Willow & Veil | Bridal Makeup Artist in Austin, TX',
			'description' => 'Meet the lead artist and owner of Willow & Veil, bringing over 10 years of bridal hair and makeup artistry to brides in Austin, Texas.',
			'menu'        => 'About',
		),
		array(
			'slug'        => 'our-team',
			'title'       => 'Our Team',
			'seo_title'   => 'Our Team | Willow & Veil Bridal Hair & Makeup, Austin, TX',
			'description' => 'Meet the Willow & Veil team of bridal hair and makeup artists serving weddings in and around Austin, Texas.',
			'menu'        => 'Our Team',
		),
		array(
			'slug'        => 'investment',
			'title'       => 'Investment',
			'seo_title'   => 'Investment | Bridal Hair & Makeup Prices in Austin, TX | Willow & Veil',
			'description' => 'Bridal hair and makeup investment in Austin, Texas: Signature Bridal Makeup $325, Signature Bridal Hair $325, bridal party services and wedding party collections.',
			'menu'        => 'Investment',
		),
		array(
			'slug'        => 'portfolio',
			'title'       => 'Portfolio',
			'seo_title'   => 'Bridal Hair & Makeup Portfolio | Willow & Veil, Austin, TX',
			'description' => 'Bridal, bridal party and editorial hair and makeup by Willow & Veil, luxury bridal hair and makeup in Austin, Texas.',
			'menu'        => 'Portfolio',
		),
		array(
			'slug'        => 'faq',
			'title'       => 'FAQ',
			'seo_title'   => 'Bridal Hair & Makeup FAQ | Willow & Veil, Austin, TX',
			'description' => 'Answers to common questions about booking bridal hair and makeup with Willow & Veil in Austin, Texas: deposits, previews, travel, minimums and bridal parties.',
			'menu'        => 'FAQ',
		),
		array(
			'slug'        => 'contact',
			'title'       => 'Contact',
			'seo_title'   => 'Inquire | Book Bridal Hair & Makeup in Austin, TX | Willow & Veil',
			'description' => 'Inquire about bridal hair and makeup with Willow & Veil in Austin, Texas. Share your wedding date, time, location and how many people need hair and makeup.',
			'menu'        => 'Contact',
		),
	);
}

/**
 * Imports theme images into the media library. Returns slug => attachment ID.
 */
function wv_import_images() {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$dir      = get_template_directory() . '/assets/images/content/';
	$manifest = json_decode( file_get_contents( $dir . 'manifest.json' ), true );
	$ids      = array();

	foreach ( $manifest as $item ) {
		$existing = get_posts(
			array(
				'post_type'   => 'attachment',
				'post_status' => 'inherit',
				'meta_key'    => '_wv_slug',
				'meta_value'  => $item['slug'],
				'fields'      => 'ids',
				'numberposts' => 1,
			)
		);
		if ( $existing ) {
			$ids[ $item['slug'] ] = (int) $existing[0];
			continue;
		}

		$tmp = wp_tempnam( $item['slug'] . '.webp' );
		copy( $dir . $item['slug'] . '.webp', $tmp );
		$file = array(
			'name'     => $item['slug'] . '.webp',
			'tmp_name' => $tmp,
		);
		$id   = media_handle_sideload( $file, 0, $item['alt'] );
		if ( is_wp_error( $id ) ) {
			@unlink( $tmp );
			continue;
		}
		update_post_meta( $id, '_wp_attachment_image_alt', $item['alt'] );
		update_post_meta( $id, '_wv_slug', $item['slug'] );
		if ( $item['cat'] ) {
			update_post_meta( $id, '_wv_category', $item['cat'] );
		}
		$ids[ $item['slug'] ] = (int) $id;
	}
	return $ids;
}

/**
 * Replaces {{tokens}} in page content with real URLs and IDs.
 */
function wv_fill_tokens( $content, $images ) {
	return preg_replace_callback(
		'/\{\{(\w+)(?::([\w-]+))?\}\}/',
		function ( $m ) use ( $images ) {
			$key = isset( $m[2] ) ? $m[2] : '';
			switch ( $m[1] ) {
				case 'id':
					return isset( $images[ $key ] ) ? (string) $images[ $key ] : '0';
				case 'img':
					return isset( $images[ $key ] ) ? esc_url( wp_get_attachment_image_url( $images[ $key ], 'large' ) ) : '';
				case 'full':
					return isset( $images[ $key ] ) ? esc_url( wp_get_attachment_image_url( $images[ $key ], 'full' ) ) : '';
				case 'alt':
					return isset( $images[ $key ] ) ? esc_attr( get_post_meta( $images[ $key ], '_wp_attachment_image_alt', true ) ) : '';
				case 'url':
					return esc_url( 'home' === $key ? home_url( '/' ) : wv_page_url( $key ) );
				case 'theme':
					return esc_url( get_template_directory_uri() );
				case 'email':
					return WV_EMAIL;
				case 'instagram':
					return esc_url( WV_INSTAGRAM_URL );
			}
			return $m[0];
		},
		$content
	);
}

/**
 * Main entry point.
 */
function wv_import_content() {
	$images  = wv_import_images();
	$pages   = wv_page_definitions();
	$ids     = array();

	// Pass 1: make sure every page exists so {{url:...}} tokens resolve.
	foreach ( $pages as $order => $def ) {
		$page = get_page_by_path( $def['slug'] );
		$ids[ $def['slug'] ] = $page ? $page->ID : wp_insert_post(
			array(
				'post_type'   => 'page',
				'post_status' => 'publish',
				'post_title'  => $def['title'],
				'post_name'   => $def['slug'],
				'menu_order'  => $order,
			)
		);
	}

	// Pass 2: content, excerpt (meta description) and SEO title.
	foreach ( $pages as $def ) {
		$file    = get_template_directory() . '/inc/content/' . $def['slug'] . '.html';
		$content = file_exists( $file ) ? file_get_contents( $file ) : '';
		wp_update_post(
			array(
				'ID'           => $ids[ $def['slug'] ],
				'post_content' => wv_fill_tokens( $content, $images ),
				'post_excerpt' => $def['description'],
			)
		);
		update_post_meta( $ids[ $def['slug'] ], 'wv_seo_title', $def['seo_title'] );
	}

	// Front page.
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $ids['home'] );
	update_option( 'blogname', 'Willow & Veil' );
	update_option( 'blogdescription', 'Luxury bridal hair and makeup in Austin, Texas' );

	// Menu: the header and footer navigation blocks use the most recent menu automatically.
	$links = '';
	foreach ( $pages as $def ) {
		if ( ! $def['menu'] ) {
			continue;
		}
		$attrs  = array(
			'label' => $def['menu'],
			'type'  => 'page',
			'id'    => $ids[ $def['slug'] ],
			'url'   => get_permalink( $ids[ $def['slug'] ] ),
			'kind'  => 'post-type',
		);
		$links .= '<!-- wp:navigation-link ' . wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES ) . ' /-->' . "\n";
	}
	foreach ( get_posts( array( 'post_type' => 'wp_navigation', 'numberposts' => -1, 'post_status' => 'any', 'fields' => 'ids' ) ) as $nav ) {
		wp_delete_post( $nav, true );
	}
	wp_insert_post(
		array(
			'post_type'    => 'wp_navigation',
			'post_status'  => 'publish',
			'post_title'   => 'Main menu',
			'post_content' => $links,
		)
	);

	// Remove WordPress starter content.
	foreach ( array( 'sample-page', 'hello-world' ) as $slug ) {
		$post = get_page_by_path( $slug, OBJECT, array( 'page', 'post' ) );
		if ( $post ) {
			wp_delete_post( $post->ID, true );
		}
	}

	return array(
		'images' => count( $images ),
		'pages'  => count( $ids ),
	);
}

/**
 * Admin screen so the same setup can be run on live hosting with one click.
 */
add_action(
	'admin_menu',
	function () {
		add_theme_page(
			__( 'Willow & Veil Setup', 'willow-and-veil' ),
			__( 'Willow & Veil Setup', 'willow-and-veil' ),
			'manage_options',
			'wv-setup',
			function () {
				$result = null;
				if ( isset( $_POST['wv_run_setup'] ) && check_admin_referer( 'wv_setup' ) ) {
					$result = wv_import_content();
				}
				echo '<div class="wrap"><h1>' . esc_html__( 'Willow & Veil Setup', 'willow-and-veil' ) . '</h1>';
				if ( $result ) {
					printf( '<div class="notice notice-success"><p>Imported %d images and %d pages.</p></div>', (int) $result['images'], (int) $result['pages'] );
				}
				echo '<p>Creates the site pages, menu and media library images. Existing pages with the same names have their content replaced, so only run this on a new site.</p>';
				echo '<form method="post">';
				wp_nonce_field( 'wv_setup' );
				submit_button( __( 'Run setup', 'willow-and-veil' ), 'primary', 'wv_run_setup' );
				echo '</form></div>';
			}
		);
	}
);
