<?php
/**
 * Lightweight on-page SEO without a plugin.
 *
 * Page title: the "SEO title" custom field (wv_seo_title) if set, otherwise the normal WordPress title.
 * Meta description: the page excerpt. Both can be edited in the page editor sidebar.
 * If an SEO plugin such as Yoast is installed later, this file steps aside automatically.
 *
 * @package willow-and-veil
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	function () {
		register_post_meta(
			'page',
			'wv_seo_title',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'edit_pages' );
				},
			)
		);
	}
);

function wv_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || class_exists( 'All_in_One_SEO_Pack' ) || defined( 'AIOSEO_VERSION' );
}

add_filter(
	'pre_get_document_title',
	function ( $title ) {
		if ( wv_seo_plugin_active() || ! is_singular() ) {
			return $title;
		}
		$custom = get_post_meta( get_queried_object_id(), 'wv_seo_title', true );
		return $custom ? esc_html( $custom ) : $title;
	}
);

add_action(
	'wp_head',
	function () {
		if ( wv_seo_plugin_active() ) {
			return;
		}
		$description = is_singular() ? get_the_excerpt( get_queried_object_id() ) : get_bloginfo( 'description' );
		$description = trim( wp_strip_all_tags( (string) $description ) );
		if ( '' === $description ) {
			return;
		}
		printf( '<meta name="description" content="%s" />' . "\n", esc_attr( $description ) );
		printf( '<meta property="og:title" content="%s" />' . "\n", esc_attr( wp_get_document_title() ) );
		printf( '<meta property="og:description" content="%s" />' . "\n", esc_attr( $description ) );
		printf( '<meta property="og:type" content="website" />' . "\n" );
		if ( is_singular() ) {
			printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( get_permalink( get_queried_object_id() ) ) );
		}
	},
	2
);

// WordPress core already prints a canonical link on singular pages; avoid a duplicate.
remove_action( 'wp_head', 'rel_canonical' );
