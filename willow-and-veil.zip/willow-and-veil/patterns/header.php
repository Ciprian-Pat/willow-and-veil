<?php
/**
 * Title: Site header
 * Slug: willow-and-veil/header
 * Categories: header
 * Block Types: core/template-part/header
 * Inserter: no
 */
$wv_contact = wv_page_url( 'contact' );
?>
<!-- wp:group {"className":"wv-header","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group wv-header"><!-- wp:group {"className":"wv-brand","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group wv-brand"><!-- wp:html -->
<a class="wv-brand__link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
	<img class="wv-brand__mark" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/brand/logo-monogram.webp' ) ); ?>" alt="" width="388" height="295" />
	<span class="wv-brand__text">
		<span class="wv-brand__name">Willow &amp; Veil</span>
		<span class="wv-brand__rule" aria-hidden="true"></span>
	</span>
	<span class="screen-reader-text">, bridal hair and makeup, home</span>
</a>
<!-- /wp:html --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"wv-header__actions","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group wv-header__actions"><!-- wp:navigation {"overlayMenu":"mobile","className":"wv-nav","layout":{"type":"flex","justifyContent":"right"}} /-->

<!-- wp:pattern {"slug":"willow-and-veil/social-links"} /-->

<!-- wp:buttons {"className":"wv-header__cta"} -->
<div class="wp-block-buttons wv-header__cta"><!-- wp:button {"className":"wv-btn-small"} -->
<div class="wp-block-button wv-btn-small"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $wv_contact ); ?>">Inquire</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
