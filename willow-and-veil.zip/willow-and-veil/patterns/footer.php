<?php
/**
 * Title: Site footer
 * Slug: willow-and-veil/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 * Inserter: no
 */
$wv_strip = array(
	'bridal-party-parasols'    => 'Bridesmaids in white waffle robes laughing with paper parasols',
	'editorial-veil-waves'     => 'Glossy brunette waves with a lace leaf-trimmed veil, seen from behind',
	'couple-lakeside-walk'     => 'Bride with a soft textured updo walking arm in arm with her groom beside the water',
	'getting-ready-lip-liner'  => 'Makeup artist applying berry lip color to a bride in a lace gown',
	'two-brides-confetti'      => 'Two laughing brides walking hand in hand through petal confetti',
	'editorial-twisted-updo'   => 'Sleek twisted updo with gold hoop earrings, seen in profile',
);
?>
<!-- wp:group {"className":"wv-photo-strip","layout":{"type":"default"}} -->
<div class="wp-block-group wv-photo-strip"><!-- wp:html -->
<ul class="wv-photo-strip__list" aria-label="Recent work on Instagram">
<?php foreach ( $wv_strip as $wv_slug => $wv_alt ) : ?>
	<li><a href="<?php echo esc_url( WV_INSTAGRAM_URL ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/content/' . $wv_slug . '.webp' ) ); ?>" alt="<?php echo esc_attr( $wv_alt ); ?>" loading="lazy" decoding="async" /></a></li>
<?php endforeach; ?>
</ul>
<!-- /wp:html --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"wv-footer","layout":{"type":"constrained","contentSize":"1280px"}} -->
<div class="wp-block-group wv-footer"><!-- wp:columns {"className":"wv-footer__cols"} -->
<div class="wp-block-columns wv-footer__cols"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:html -->
<a class="wv-footer__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/brand/logo-full.webp' ) ); ?>" alt="Willow &amp; Veil, bridal hair and makeup, Austin, Texas" width="638" height="549" loading="lazy" /></a>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"wv-footer__lede"} -->
<p class="wv-footer__lede">Timeless, elevated makeup artistry designed to photograph beautifully and last throughout your wedding day.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"className":"wv-footer__title"} -->
<h2 class="wp-block-heading wv-footer__title">Explore</h2>
<!-- /wp:heading -->

<!-- wp:navigation {"overlayMenu":"never","className":"wv-footer__nav","ariaLabel":"Footer","layout":{"type":"flex","orientation":"vertical"}} /--></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"className":"wv-footer__title"} -->
<h2 class="wp-block-heading wv-footer__title">Contact</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><a href="mailto:<?php echo esc_attr( WV_EMAIL ); ?>"><?php echo esc_html( WV_EMAIL ); ?></a><br><a href="<?php echo esc_url( WV_INSTAGRAM_URL ); ?>">@mualydia.fletcher</a><br>Austin, Texas</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"wv-small"} -->
<p class="wv-small">Complimentary within 20 miles of Austin.</p>
<!-- /wp:paragraph -->

<!-- wp:pattern {"slug":"willow-and-veil/social-links"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:paragraph {"className":"wv-footer__legal"} -->
<p class="wv-footer__legal">&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> Willow &amp; Veil. Bridal Hair &amp; Makeup, Austin, Texas.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"wv-marquee wv-marquee--footer","layout":{"type":"default"}} -->
<div class="wp-block-group wv-marquee wv-marquee--footer"><!-- wp:paragraph {"className":"wv-marquee__text"} -->
<p class="wv-marquee__text">Willow &amp; Veil <span class="wv-sep" aria-hidden="true">✦</span> Bridal Hair &amp; Makeup <span class="wv-sep" aria-hidden="true">✦</span> Austin, Texas <span class="wv-sep" aria-hidden="true">✦</span> I can’t wait to be part of your story <span class="wv-sep" aria-hidden="true">✦</span></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
