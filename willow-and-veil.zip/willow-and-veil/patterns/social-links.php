<?php
/**
 * Title: Social links
 * Slug: willow-and-veil/social-links
 * Categories: willow-and-veil
 * Inserter: no
 *
 * Facebook, TikTok and Pinterest point at placeholder anchors until the accounts exist.
 */
?>
<!-- wp:social-links {"size":"has-small-icon-size","className":"is-style-logos-only wv-social"} -->
<ul class="wp-block-social-links has-small-icon-size is-style-logos-only wv-social"><!-- wp:social-link {"url":"<?php echo esc_url( WV_INSTAGRAM_URL ); ?>","service":"instagram","label":"Willow & Veil on Instagram"} /-->

<!-- wp:social-link {"url":"#placeholder-facebook-url","service":"facebook","label":"Willow & Veil on Facebook"} /-->

<!-- wp:social-link {"url":"#placeholder-tiktok-url","service":"tiktok","label":"Willow & Veil on TikTok"} /-->

<!-- wp:social-link {"url":"#placeholder-pinterest-url","service":"pinterest","label":"Willow & Veil on Pinterest"} /--></ul>
<!-- /wp:social-links -->
