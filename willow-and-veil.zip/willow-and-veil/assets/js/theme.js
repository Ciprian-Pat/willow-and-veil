/**
 * Willow & Veil front-end behavior.
 * 1. Marquee bands: repeats the text so it scrolls seamlessly. Copies are hidden from screen readers.
 * 2. Portfolio filter: builds category buttons from the caption of each Gallery block.
 */
( function () {
	'use strict';

	function setupMarquees() {
		var reduce = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		document.querySelectorAll( '.wv-marquee' ).forEach( function ( band ) {
			var source = band.querySelector( '.wv-marquee__text' );
			if ( ! source || reduce || band.dataset.ready ) {
				return;
			}
			band.dataset.ready = '1';

			var track = document.createElement( 'div' );
			track.className = 'wv-marquee__track';
			source.parentNode.insertBefore( track, source );
			track.appendChild( source );

			// Fill at least one screen width, then duplicate the whole set for a seamless loop.
			var guard = 0;
			while ( track.scrollWidth < window.innerWidth * 1.2 && guard++ < 12 ) {
				track.appendChild( makeCopy( source ) );
			}
			Array.prototype.slice.call( track.children ).forEach( function ( node ) {
				track.appendChild( makeCopy( node ) );
			} );

			var pxPerSecond = 45;
			track.style.setProperty( '--wv-marquee-duration', Math.max( 20, track.scrollWidth / 2 / pxPerSecond ) + 's' );
		} );
	}

	function makeCopy( node ) {
		var copy = node.cloneNode( true );
		copy.setAttribute( 'aria-hidden', 'true' );
		return copy;
	}

	function setupPortfolio() {
		var grid = document.querySelector( '.wv-portfolio-grid' );
		if ( ! grid ) {
			return;
		}
		var galleries = Array.prototype.slice.call( grid.querySelectorAll( ':scope > .wp-block-gallery' ) );
		if ( galleries.length < 2 ) {
			return;
		}

		var list = document.createElement( 'ul' );
		list.className = 'wv-portfolio-filter';
		list.setAttribute( 'aria-label', 'Filter portfolio by category' );

		var status = document.createElement( 'p' );
		status.className = 'screen-reader-text';
		status.setAttribute( 'role', 'status' );

		var buttons = [];
		function addButton( label, gallery ) {
			var li = document.createElement( 'li' );
			var btn = document.createElement( 'button' );
			btn.type = 'button';
			btn.textContent = label;
			btn.setAttribute( 'aria-pressed', gallery ? 'false' : 'true' );
			btn.addEventListener( 'click', function () {
				var count = 0;
				galleries.forEach( function ( g ) {
					var show = ! gallery || g === gallery;
					g.hidden = ! show;
					if ( show ) {
						count += g.querySelectorAll( 'figure.wp-block-image' ).length;
					}
				} );
				buttons.forEach( function ( b ) {
					b.setAttribute( 'aria-pressed', b === btn ? 'true' : 'false' );
				} );
				status.textContent = 'Showing ' + count + ' photos: ' + label;
			} );
			buttons.push( btn );
			li.appendChild( btn );
			list.appendChild( li );
		}

		addButton( 'All', null );
		galleries.forEach( function ( g, i ) {
			var caption = g.querySelector( ':scope > figcaption' );
			addButton( caption ? caption.textContent.trim() : 'Gallery ' + ( i + 1 ), g );
		} );

		grid.parentNode.insertBefore( list, grid );
		grid.parentNode.insertBefore( status, grid );
	}

	var reduceMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	// 3. Home carousel: arrow buttons, gentle autoplay that pauses on hover, focus or touch.
	function setupCarousel() {
		document.querySelectorAll( '.wp-block-gallery.wv-carousel' ).forEach( function ( track ) {
			var wrap = document.createElement( 'div' );
			wrap.className = 'wv-carousel-wrap alignfull';
			track.parentNode.insertBefore( wrap, track );
			wrap.appendChild( track );
			track.setAttribute( 'tabindex', '0' );
			track.setAttribute( 'aria-label', 'Recent work, scroll sideways or use the arrow buttons' );

			var arrow = '<svg viewBox="0 0 44 16" aria-hidden="true" focusable="false"><path d="M0 8h42M35 1l7 7-7 7" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>';
			function makeButton( dir ) {
				var b = document.createElement( 'button' );
				b.type = 'button';
				b.className = 'wv-carousel__nav wv-carousel__nav--' + dir;
				b.setAttribute( 'aria-label', dir === 'prev' ? 'Previous photos' : 'Next photos' );
				b.innerHTML = arrow;
				if ( dir === 'prev' ) {
					b.querySelector( 'svg' ).style.transform = 'scaleX(-1)';
				}
				wrap.appendChild( b );
				return b;
			}
			var prev = makeButton( 'prev' );
			var next = makeButton( 'next' );

			function step() {
				var first = track.querySelector( 'figure' );
				var gap = parseFloat( getComputedStyle( track ).columnGap ) || 16;
				return first ? first.getBoundingClientRect().width + gap : track.clientWidth * 0.8;
			}
			function atEnd() {
				return track.scrollLeft + track.clientWidth >= track.scrollWidth - 4;
			}
			function update() {
				prev.disabled = track.scrollLeft <= 4;
				next.disabled = atEnd();
			}
			prev.addEventListener( 'click', function () { track.scrollBy( { left: -step() } ); } );
			next.addEventListener( 'click', function () { track.scrollBy( { left: step() } ); } );
			track.addEventListener( 'scroll', update, { passive: true } );
			window.addEventListener( 'resize', update );
			update();

			if ( reduceMotion ) {
				return;
			}
			var paused = false;
			[ 'mouseenter', 'focusin', 'pointerdown' ].forEach( function ( e ) { wrap.addEventListener( e, function () { paused = true; } ); } );
			[ 'mouseleave', 'focusout' ].forEach( function ( e ) { wrap.addEventListener( e, function () { paused = false; } ); } );
			setInterval( function () {
				if ( paused || document.hidden ) {
					return;
				}
				if ( atEnd() ) {
					track.scrollTo( { left: 0 } );
				} else {
					track.scrollBy( { left: step() } );
				}
			}, 4500 );
		} );
	}

	// 4. Sections fade up as they scroll into view.
	function setupReveal() {
		if ( reduceMotion || ! ( 'IntersectionObserver' in window ) ) {
			return;
		}
		var selectors = [
			'.wv-section-head', '.wv-card', '.wv-why__item', '.wv-testimonial', '.wv-collection', '.wv-team-card',
			'.wv-split > .wp-block-column', '.wv-menu-col', '.wv-faq .wp-block-details', '.wv-terms', '.wv-contact-card',
			'.wv-intro > *', '.wv-page-hero > *', '.wv-artist__text > *', '.wv-story > *', '.wv-bg-ink > *',
			'.wv-instagram-feed > figure', '.wv-photo-strip__list li', '.wv-footer__cols > .wp-block-column'
		];
		var items = document.querySelectorAll( selectors.join( ',' ) );
		var observer = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					entry.target.classList.add( 'is-visible' );
					observer.unobserve( entry.target );
				}
			} );
		}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 } );

		items.forEach( function ( el ) {
			var siblings = Array.prototype.filter.call( el.parentNode.children, function ( c ) { return c.matches( selectors.join( ',' ) ); } );
			var index = Math.min( siblings.indexOf( el ), 6 );
			el.style.setProperty( '--wv-delay', ( index * 0.09 ) + 's' );
			el.classList.add( 'wv-reveal' );
			observer.observe( el );
		} );

		document.querySelectorAll( '.wv-split .wp-block-image, .wv-artist__media .wp-block-image, .wv-portrait, .wv-team-card .wp-block-image' ).forEach( function ( el ) {
			el.classList.add( 'wv-reveal-img' );
			observer.observe( el );
		} );
	}

	// 5. Header tightens once the page scrolls; on the home page the name fades in after the wordmark.
	function setupHeader() {
		var root = document.documentElement;
		if ( document.body.classList.contains( 'home' ) ) {
			root.classList.add( 'wv-home' );
		}
		var ticking = false;
		function onScroll() {
			if ( ticking ) {
				return;
			}
			ticking = true;
			requestAnimationFrame( function () {
				root.classList.toggle( 'is-scrolled', window.scrollY > 40 );
				ticking = false;
			} );
		}
		window.addEventListener( 'scroll', onScroll, { passive: true } );
		onScroll();
	}

	// 6. Wordmark entrance.
	function setupHero() {
		var hero = document.querySelector( '.wv-brand-hero' );
		if ( hero ) {
			requestAnimationFrame( function () {
				requestAnimationFrame( function () { hero.classList.add( 'is-loaded' ); } );
			} );
		}
	}

	function init() {
		setupMarquees();
		setupPortfolio();
		setupCarousel();
		setupReveal();
		setupHeader();
		setupHero();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
