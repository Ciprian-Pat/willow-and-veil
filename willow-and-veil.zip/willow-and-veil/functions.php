<?php
/**
 * Willow & Veil theme functions.
 *
 * @package willow-and-veil
 */

defined( 'ABSPATH' ) || exit;

// Business details used across patterns. Update these when the real accounts exist.
define( 'WV_EMAIL', 'hello@example.com' ); // [PLACEHOLDER: enquiry email address]
define( 'WV_INSTAGRAM_URL', 'https://www.instagram.com/mualydia.fletcher/' );
define( 'WV_VERSION', wp_get_theme( get_template() )->get( 'Version' ) );

require get_template_directory() . '/inc/seo.php';
require get_template_directory() . '/inc/importer.php';

/**
 * Permalink for a page by slug, falling back to a pretty URL if the page does not exist yet.
 */
function wv_page_url( $slug ) {
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
}

add_action(
	'after_setup_theme',
	function () {
		add_theme_support( 'title-tag' );
		add_theme_support( 'editor-styles' );
		add_editor_style( 'assets/css/theme.css' );
		add_post_type_support( 'page', 'excerpt' );
	}
);

add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'willow-and-veil', get_theme_file_uri( 'assets/css/theme.css' ), array(), WV_VERSION );
		wp_enqueue_script( 'willow-and-veil', get_theme_file_uri( 'assets/js/theme.js' ), array(), WV_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
	}
);

add_action(
	'init',
	function () {
		register_block_pattern_category( 'willow-and-veil', array( 'label' => __( 'Willow & Veil', 'willow-and-veil' ) ) );
	}
);

// Preload the heading font so the serif titles do not flash, and flag that JavaScript is on
// so entrance animations only hide content when the script that reveals it can run.
add_action(
	'wp_head',
	function () {
		echo "<script>document.documentElement.classList.add('wv-js');</script>\n";
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_theme_file_uri( 'assets/fonts/instrument-serif-normal.woff2' ) )
		);
	},
	1
);
